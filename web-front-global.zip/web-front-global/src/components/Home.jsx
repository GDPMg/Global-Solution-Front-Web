import React from 'react';
import { useNavigate } from 'react-router-dom';
import './Home.scss';
import Card_Imagem1 from '../imagens/imagem_do_card.jpg';
import Card_Imagem2 from '../imagens/imagem_do_card2.jpg';
import Card_Imagem3 from '../imagens/imagem_do_card3.png';

function Home() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Limpar dados de sessão
    sessionStorage.removeItem('Logado');
    sessionStorage.removeItem('username');

    // Redirecionar para a tela de login
    navigate('/');
  };

  return (
    <>
      <main>
        {/* Seção de logout */}
        <div className="logout">
          <button onClick={handleLogout}>Logout</button>
        </div>
        {/* Artigo principal com informações sobre a solução */}
        <article className="container-principal">
          <img
            src="https://sensorweb.com.br/wp-content/uploads/2018/12/Imagem-e1461692956634.png"
            id="imagem"
            alt="Imagem"
          />
          {/* Informações sobre a solução */}
          <div className="sobre">
            <h3>HealthTech</h3>
            <p>
              Desenvolvemos um dispositivo inovador para o armazenamento de
              medicamentos termolábeis, permitindo aos usuários configurar e
              monitorar a temperatura em tempo real.
            </p>
          </div>
          {/* Botão para mais informações */}
          <div className="botao">
            <input type="submit" value="Mais Informações" />
          </div>
        </article>
        {/* Caixa de texto com informações detalhadas do que é a solução, o que ele fará e como funcionará */}
        <div className="Box-texto">
          {/* Texto 1 */}
          <div className="texto1">
            <h2>O que é a solução</h2>
            <p>
              Essa tecnologia não apenas aumenta a acessibilidade aos
              medicamentos, reduzindo custos associados ao armazenamento
              inadequado, mas também facilita o transporte eficiente,
              especialmente para empresas de delivery. A implementação
              bem-sucedida deste dispositivo tem o potencial de transformar
              positivamente a vida de pacientes, melhorando a qualidade de vida
              e contribuindo significativamente para a saúde pública.
            </p>
          </div>
          {/* Texto 2 */}
          <div className="texto2">
            <h2>O que ele fará</h2>
            <p>
              1. Controle de Temperatura: Configurar a temperatura desejada para
              o armazenamento do medicamento, garantindo condições ideais de
              conservação. <br />
              2. Monitoramento em Tempo Real: Fornecer informações em tempo
              real sobre a temperatura do local de armazenamento durante o
              transporte do medicamento, assegurando sua integridade. <br />
            </p>
          </div>
          
          {/* Texto 3 */}
          <div className="texto3">
            <h2>Como funcionará</h2>
            <p>
              1. Configuração Inicial: Ao receber o dispositivo, o cliente
              seguirá as instruções fornecidas para a configuração inicial. Isso
              pode envolver o carregamento da bateria (se aplicável) e a
              ativação do dispositivo. <br />
              2. Configuração da Temperatura: Usando a interface do usuário no
              dispositivo ou um aplicativo conectado, o cliente definirá a
              temperatura desejada para o armazenamento do medicamento. Isso pode
              ser feito através de botões, uma tela sensível ao toque ou comandos
              no aplicativo, dependendo do modelo do dispositivo.
            </p>
          </div>
        </div>

        {/* Vantagens da solução */}
        <h2 id="vantagens">Vantagens</h2>
        <div className="card-vantagem">
          {/* Card 1 */}
          <article className="cards-inteiro">
            <img src={Card_Imagem1} alt="Card1" />
            <div className="card-texto">
              <h3>Acessibilidade Aprimorada</h3>
              <p>
                Este projeto proporciona uma solução inovadora para a falta de
                acessibilidade no armazenamento de medicamentos termolábeis. Ao
                tornar o dispositivo acessível e fácil de usar, a população em
                geral terá a capacidade de manter seus medicamentos de maneira
                adequada, superando barreiras que antes limitavam o acesso a
                esses tratamentos.
              </p>
            </div>
          </article>

          {/* Card 2 */}
          <article className="cards-inteiro">
            <img src={Card_Imagem2} alt="Card2" />
            <div className="card-texto">
              <h3>Monitoramento Eficiente em Tempo Real:</h3>
              <p>
                A inclusão da funcionalidade de monitoramento em tempo real
                oferece aos usuários a capacidade de verificar continuamente as
                condições de armazenamento de seus medicamentos, especialmente
                durante o transporte. Isso garante que os medicamentos permaneçam
                em temperatura ideal, proporcionando tranquilidade aos usuários
                quanto à eficácia e integridade dos tratamentos.
              </p>
            </div>
          </article>
          
          {/* Card 3 */}
          <article className="cards-inteiro">
            <img src={Card_Imagem3} alt="Card3" />
            <div className="card-texto">
              <h3>Redução de Desperdício de Medicamentos</h3>
              <p>
                Ao garantir condições ideais de armazenamento, o projeto
                contribui para a redução do desperdício de medicamentos
                termolábeis. Muitos medicamentos podem perder eficácia se não
                forem armazenados corretamente, e o dispositivo ajuda a evitar a
                deterioração prematura, economizando recursos e reduzindo a
                necessidade de substituições frequentes.
              </p>
            </div>
          </article>
        </div>
      </main>
    </>
  );
}

export default Home;

