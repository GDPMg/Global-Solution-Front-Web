import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.scss';
import dados from './banco_de_dados.json';

function Login() {

  // Define estados para o nome de usuário, senha, e se o usuário está logado
  const [username, usuario] = useState('');
  const [password, senha] = useState('');
  const [Logado, setLoggedIn] = useState(false);
  const navigate = useNavigate(); 
  

  // Função chamada ao enviar o formulário
  const handleSubmit = (e) => {
    e.preventDefault();

    console.log('Data:', dados);


    // Procura um usuário nos dados com o nome de usuário e senha fornecidos
    const user = dados.find((user) => user.usuario === username && user.senha === password);

    console.log('Username:', username);
    console.log('Password:', password);

    if (user) {
      console.log('Login feito com sucesso!', user);

      // Armazena informações na sessão
      sessionStorage.setItem('Logado', 'true');
      sessionStorage.setItem('username', username);

      setLoggedIn(true);

      
      navigate('/home');
    } else {
      console.log('senha ou usuário errados');
    }
  };

  if (Logado) {

    return null; 
  }

  return (
<>
     {/*Div que envolve o formulário de login*/}
    <div className="box-Login">
      {/*Formulário de login*/}
      <form onSubmit={handleSubmit}>
        <label className="label1" htmlFor="username">Usuário</label>
          <input
            type="text"
            id="username"
            name="username"
            value={username}
            onChange={(e) => usuario(e.target.value)}
          />
        


        <label className="label2" htmlFor="password">Senha</label>
          <input
            type="password"
            id="password"
            name="password"
            value={password}
            onChange={(e) => senha(e.target.value)}
          />
          
        {/* Botão de envio do formulário */}
        <button className="press-login" type="submit">Login</button>
      </form>
    </div>

    </>
  );
}

export default Login;
