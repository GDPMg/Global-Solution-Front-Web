import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './Login.scss';
import data from './dados.json';

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [Logado, setLoggedIn] = useState(false);
  const navigate = useNavigate(); // Hook useNavigate para redirecionamento

  const handleSubmit = (e) => {
    e.preventDefault();

    console.log('Data:', data);

    const user = data.find((user) => user.usuario === username && user.senha === password);

    console.log('Username:', username);
    console.log('Password:', password);

    if (user) {
      console.log('Login bem-sucedido!', user);

      sessionStorage.setItem('Logado', 'true');
      sessionStorage.setItem('username', username);

      setLoggedIn(true);
      
      
        navigate('/home');
    } else {
      console.log('Usuário ou senha incorretos');
    }
  };

  if (Logado) {
    
      return null; 
  }

  return (
    <>
    
      <div className="Login">
        <form onSubmit={handleSubmit}>
              <label className="label-usuario" htmlFor="username">Usuário</label>
              <input
                type="text"
                id="username"
                name="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
              />
            
              <label className="label-senha" htmlFor="password">Senha</label>
              <input
                type="password"
                id="password"
                name="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            
          <button className="botao-login" type="submit">Login</button>
        </form>
      </div>
    
    </>
  );
}

export default Login;